# Atmega

## Description

This is a [LibrePCB](https://librepcb.org) library!
Just edit this file to add a description about it.

## License

Creative Commons (CC0-1.0). For the license text, see [LICENSE.txt](LICENSE.txt).
